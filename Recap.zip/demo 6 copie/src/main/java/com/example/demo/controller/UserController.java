package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUser();
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return userService.getUserById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        return ResponseEntity.ok(userService.createUser(user));
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        try {
            return ResponseEntity.ok(userService.updateUser(id, userDetails));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/{id}/follow/{followId}")
    public ResponseEntity<User> followUser(@PathVariable Long id, @PathVariable Long followId)
    {
    	try {
    		return ResponseEntity.ok(userService.followUser(id, followId));
    	}
    	catch (RuntimeException e) {
    		return ResponseEntity.notFound().build();
    	}

    }
    
    @PostMapping("/{id}/unfollow/{followId}")
    public ResponseEntity<User> unFollowUser(@PathVariable Long id, @PathVariable Long followId)
    {
    	try {
    		return ResponseEntity.ok(userService.unFollowUser(id, followId));
    	}
    	catch (RuntimeException e) {
    		return ResponseEntity.notFound().build();
    	}

    }
}
