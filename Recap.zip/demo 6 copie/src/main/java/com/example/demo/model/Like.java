package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
@IdClass(value=Like.class)
public class Like {
	@Id
	private Long userId;
	
	
	@Id
	private Long messageId;
	
	
	@ManyToOne
	@JoinColumn(name="userId")
	@JsonBackReference // Regarder si dans user, il existe un type Like
	private User user;
	
	@ManyToOne
	@JoinColumn(name="messageId")
	@JsonBackReference
	private Message message;
	
}
