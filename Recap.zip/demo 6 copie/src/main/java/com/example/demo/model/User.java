package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;

@Entity
@Table(name="users")
@Getter
public class User {
	
	// Identity -> iD AUTO-INCREMENT
	// SEQUENCE -> Hibernate valeur ID
	// Table -> Hibernate va creer une table speciale  <- Sous-optimal configuration spéciale
	// Auto choix en fonction de la bdd
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;

	// @Column(nullable=false, length=20)
	private String email;
	
	// @Column(nullable=false, precision=4, scale=3, updatable=false, columnDefinition="") //0000 et 9999 1.001 a 9999
	private Integer credit;
	
	@ManyToMany
	@JoinTable(
			name="followers",
			joinColumns = @JoinColumn(name="follower_id"),
			inverseJoinColumns =  @JoinColumn(name="following_id")
			)
	private List<User> following = new ArrayList<User>();
	
	
	@OneToMany(mappedBy="user", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonManagedReference
	private List<Like> likes;

	public long getId() {
		return id;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public List<User> getFollowing() {
		return following;
	}


	public void setFollowing(List<User> following) {
		this.following = following;
	}

}