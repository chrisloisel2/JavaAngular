package com.example.demo.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {

    @Pointcut("within(com.example.demo.controller..*)")
    public void controllerPointcut() {
    }

    @Before("controllerPointcut()")
    public void logBefore(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();
        System.out.println("Avant la méthode : " + methodName + " avec arguments : " + Arrays.toString(args));
    }

    @AfterReturning(pointcut = "controllerPointcut()", returning = "response")
    public void logAfter(JoinPoint joinPoint, Object response) {
        String methodName = joinPoint.getSignature().getName();
        System.out.println("Après la méthode : " + methodName + " avec réponse : " + response);
    }

    @Around("controllerPointcut()")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object result = joinPoint.proceed();
        long end = System.currentTimeMillis();
        String methodName = joinPoint.getSignature().getName();
        System.out.println("Méthode : " + methodName + " exécutée en " + (end - start) + " ms");
        return result;
    }
}
