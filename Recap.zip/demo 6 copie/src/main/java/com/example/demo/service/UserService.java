package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    

    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User updateUser(Long id, User userDetails) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found with id " + id));
        user.setName(userDetails.getName());
        user.setEmail(userDetails.getEmail());
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found with id " + id));
        userRepository.delete(user);
    }

	public User followUser(Long id, Long followId) {
		// TODO Auto-generated method stub
		User currentUser = this.getUserById(id).get();
		User followUser = this.getUserById(followId).get();
		currentUser.getFollowing().add(followUser);
		return userRepository.save(currentUser);
		
	}
    
	public User unFollowUser(Long id, Long followId) {
		// TODO Auto-generated method stub
		User currentUser = this.getUserById(id).get();
		User followUser = this.getUserById(followId).get();
		currentUser.getFollowing().remove(followUser);
		return userRepository.save(currentUser);
		
	}
    
    
}
